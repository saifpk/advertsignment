<?php if (!defined('FW')) {
    die('Forbidden');
}

$cfg = array();

$cfg['page_builder'] = array(
    'title'       => 'Smart Slider',
    'description' => 'Adds Smart Slider into the page',
    'tab'         => __('Media Elements', 'fw'),
);
